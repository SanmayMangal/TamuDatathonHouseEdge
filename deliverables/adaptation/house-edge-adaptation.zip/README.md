# House Edge submission (adaptation round): generalized Bayesian rule model

## Entry

- Team: Card Sharks
- Round: adaptation
- Season ID: 5fffdc4d0c700bbf61c3f911 (`public/metadata.json`)
- Forecast file: `submission.csv` (uploaded separately; not in this ZIP)
- Forecast SHA-256: 08194b550e9cf68345a8100c0137bb2d3cfeecd82402ff05d0b1e5e58473b7b2
- Environment: `python` (`reproduce.json`). **Python standard library only**; no `requirements.txt`.

## Setup

- Python 3.13 (tested 3.13.18); uses only `argparse`, `csv`, `json`, `math`, `pathlib`.
- Hardware: 1 CPU core is enough; measured 2.2 s for the test split.
- Data: the round's public folder at `/data` (reads `/data/test/queries.csv`, `/data/test/history.csv`).

## Recreate the forecast

```sh
python predict.py --data /data --out /output/submission.csv
```

- Output: `/output/submission.csv` with columns `query_id,p_0,p_1,p_2,p_5,p_20`.
- Model file: `hyperparameters.json` (checkpoint). No randomness; float64; deterministic.
- Training (separate, not needed for reproduction): `python training/fit.py --data path/to/public --splits train,validation --out hyperparameters.json`
  (numpy, pandas, scipy). Fitted on this round's train + validation splits only.

## Model

Bayesian rule model. Each machine's win chance follows a rule: the even parity of its encoded outcomes at a
learned set of lags (single lag, pair or triple; this round: encoding `win`, top rules
(3, 8) 0.34, (1, 4) 0.32, (2, 6) 0.31, (1, 4, 8) 0.00), with a machine-specific favorable side
and at most one direction flip (P(flip) 0.67 long / 0.06 short).
Posterior over (rule, direction, flip) with Beta-Bernoulli likelihoods; episode and machine log-odds
offsets; 1x share and 2x:5x:20x split shrunk per machine toward type means.

Validation with train-only fit: Validation points: 18.682381 / 20

## Local check

- Checker: `VALID FORMAT: 1536 queries | adaptation | test`
- Fresh-folder reproduction: see `repro` line in the pipeline log (ZIP extracted read-only, rerun, byte comparison).
